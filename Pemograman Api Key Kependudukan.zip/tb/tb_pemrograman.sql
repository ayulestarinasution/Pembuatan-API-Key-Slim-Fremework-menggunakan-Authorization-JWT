-- phpMyAdmin SQL Dump
-- version 4.6.6deb5ubuntu0.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 29, 2021 at 08:22 PM
-- Server version: 5.7.34-0ubuntu0.18.04.1
-- PHP Version: 7.3.28-2+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tb_pemrograman`
--

-- --------------------------------------------------------

--
-- Table structure for table `agama`
--

CREATE TABLE `agama` (
  `id_agama` int(11) NOT NULL,
  `kd_agama` varchar(25) NOT NULL,
  `agama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agama`
--

INSERT INTO `agama` (`id_agama`, `kd_agama`, `agama`) VALUES
(2, '1', 'islam'),
(3, '2', 'kristen'),
(4, '3', 'katholik'),
(5, '4', 'Buddha'),
(6, '5', 'Hindu');

-- --------------------------------------------------------

--
-- Table structure for table `aparatur_desa`
--

CREATE TABLE `aparatur_desa` (
  `id_aparatur_desa` int(11) NOT NULL,
  `nama_aparatur_desa` varchar(255) NOT NULL,
  `otoritas_surat` varchar(255) NOT NULL,
  `nip` int(11) NOT NULL,
  `foto_aparat` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aparatur_desa`
--

INSERT INTO `aparatur_desa` (`id_aparatur_desa`, `nama_aparatur_desa`, `otoritas_surat`, `nip`, `foto_aparat`) VALUES
(1, 'ujang', 'surat', 4323567, 'png'),
(4, 'jajang', 'surat', 432123, 'jajang.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `gol_darah`
--

CREATE TABLE `gol_darah` (
  `id_gol_darah` int(11) NOT NULL,
  `kd_gol_darah` varchar(25) NOT NULL,
  `gol_darah` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gol_darah`
--

INSERT INTO `gol_darah` (`id_gol_darah`, `kd_gol_darah`, `gol_darah`) VALUES
(1, '7a', 'ab'),
(2, '7b', 'a'),
(4, '7c', 'b'),
(5, '7d', 'o');

-- --------------------------------------------------------

--
-- Table structure for table `induk`
--

CREATE TABLE `induk` (
  `id_induk` int(11) NOT NULL,
  `nik` int(11) NOT NULL,
  `no_kk` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `rt` int(11) NOT NULL,
  `rw` int(11) NOT NULL,
  `tempat_lahir` varchar(50) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `nama_ayah` varchar(50) NOT NULL,
  `nama_ibu` varchar(50) NOT NULL,
  `anak_ke` int(11) NOT NULL,
  `kewarganegaraan` varchar(50) NOT NULL,
  `id_jenis_kelamin` int(11) NOT NULL,
  `id_status_hub` int(11) NOT NULL,
  `id_status_perkawinan` int(11) NOT NULL,
  `id_agama` int(11) NOT NULL,
  `id_pekerjaan` int(11) NOT NULL,
  `id_pendidikan` int(11) NOT NULL,
  `id_gol_darah` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `induk`
--

INSERT INTO `induk` (`id_induk`, `nik`, `no_kk`, `nama`, `alamat`, `rt`, `rw`, `tempat_lahir`, `tgl_lahir`, `nama_ayah`, `nama_ibu`, `anak_ke`, `kewarganegaraan`, `id_jenis_kelamin`, `id_status_hub`, `id_status_perkawinan`, `id_agama`, `id_pekerjaan`, `id_pendidikan`, `id_gol_darah`) VALUES
(9, 1234567, '12345', 'nisa', 'bandung', 2, 3, 'sumedang', '2001-09-13', 'awan', 'ningning', 2, 'indonesia', 2, 4, 2, 2, 5, 6, 1),
(10, 12345, '12345', 'sani', 'bandung', 3, 3, 'sumbawa', '2000-06-23', 'sani', 'nila', 2, 'indonesia', 2, 3, 3, 3, 5, 5, 2);

-- --------------------------------------------------------

--
-- Table structure for table `jenis_kelamin`
--

CREATE TABLE `jenis_kelamin` (
  `id_jenis_kelamin` int(11) NOT NULL,
  `kd_jenis_kelamin` varchar(25) NOT NULL,
  `jenis_kelamin` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jenis_kelamin`
--

INSERT INTO `jenis_kelamin` (`id_jenis_kelamin`, `kd_jenis_kelamin`, `jenis_kelamin`) VALUES
(1, '10a', 'laki-laki'),
(2, '10b', 'perempuan');

-- --------------------------------------------------------

--
-- Table structure for table `pekerjaan`
--

CREATE TABLE `pekerjaan` (
  `id_pekerjaan` int(11) NOT NULL,
  `kd_pekerjaan` varchar(25) NOT NULL,
  `pekerjaan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pekerjaan`
--

INSERT INTO `pekerjaan` (`id_pekerjaan`, `kd_pekerjaan`, `pekerjaan`) VALUES
(3, '16a', 'kepala desa'),
(4, '16b', 'sekertaris desa'),
(5, '16c', 'bendahara desa'),
(6, '16d', 'kaur desa'),
(7, '16e', 'bpd desa');

-- --------------------------------------------------------

--
-- Table structure for table `pendidikan`
--

CREATE TABLE `pendidikan` (
  `id_pendidikan` int(11) NOT NULL,
  `kd_pendidikan` varchar(25) NOT NULL,
  `pendidikan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pendidikan`
--

INSERT INTO `pendidikan` (`id_pendidikan`, `kd_pendidikan`, `pendidikan`) VALUES
(2, '4a', 'sd'),
(3, '4b', 'SMP'),
(4, '4c', 'SMA'),
(5, '4d', 'D3'),
(6, '4e', 'D4'),
(7, '4f', 'S1'),
(8, '4g', 'S2'),
(9, '4h', 'S3');

-- --------------------------------------------------------

--
-- Table structure for table `permohonan_ktp_wni`
--

CREATE TABLE `permohonan_ktp_wni` (
  `id_permohonan_ktp_wni` int(11) NOT NULL,
  `pesan` varchar(255) NOT NULL,
  `jenis_permohonan` varchar(255) NOT NULL,
  `waktu_pesan` date NOT NULL,
  `waktu_proses` date NOT NULL,
  `waktu_pengembalian` date NOT NULL,
  `status_pesanan` varchar(255) NOT NULL,
  `id_aparatur_desa` int(11) NOT NULL,
  `id_induk` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `permohonan_ktp_wni`
--

INSERT INTO `permohonan_ktp_wni` (`id_permohonan_ktp_wni`, `pesan`, `jenis_permohonan`, `waktu_pesan`, `waktu_proses`, `waktu_pengembalian`, `status_pesanan`, `id_aparatur_desa`, `id_induk`) VALUES
(3, 'inginmengubah ktp', 'pengubahan ktp', '2021-06-01', '2021-06-04', '2021-06-07', 'akan dibuat', 1, 9);

-- --------------------------------------------------------

--
-- Table structure for table `status_hub`
--

CREATE TABLE `status_hub` (
  `id_status_hub` int(11) NOT NULL,
  `kd_status_hub` varchar(25) NOT NULL,
  `status_hub` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status_hub`
--

INSERT INTO `status_hub` (`id_status_hub`, `kd_status_hub`, `status_hub`) VALUES
(2, '8a', 'ayah'),
(3, '8b', 'ibu'),
(4, '8c', 'anak');

-- --------------------------------------------------------

--
-- Table structure for table `status_perkawinan`
--

CREATE TABLE `status_perkawinan` (
  `id_status_perkawinan` int(11) NOT NULL,
  `kd_status_perkawinan` varchar(25) NOT NULL,
  `status_perkawinan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status_perkawinan`
--

INSERT INTO `status_perkawinan` (`id_status_perkawinan`, `kd_status_perkawinan`, `status_perkawinan`) VALUES
(2, '2a', 'belum kawin'),
(3, '2b', 'sudah kawin');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `IdUser` int(11) NOT NULL,
  `Username` varchar(255) DEFAULT NULL,
  `NamaLengkap` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `NoHp` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`IdUser`, `Username`, `NamaLengkap`, `Email`, `NoHp`, `Password`) VALUES
(1, 'user', 'user', 'user@user.com', '0822222222', 'user1234'),
(2, 'user', 'user', 'user@user.com', '0822222222', 'user1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agama`
--
ALTER TABLE `agama`
  ADD PRIMARY KEY (`id_agama`);

--
-- Indexes for table `aparatur_desa`
--
ALTER TABLE `aparatur_desa`
  ADD PRIMARY KEY (`id_aparatur_desa`);

--
-- Indexes for table `gol_darah`
--
ALTER TABLE `gol_darah`
  ADD PRIMARY KEY (`id_gol_darah`);

--
-- Indexes for table `induk`
--
ALTER TABLE `induk`
  ADD PRIMARY KEY (`id_induk`),
  ADD KEY `foreign_key_data_jenis_kelamin` (`id_jenis_kelamin`),
  ADD KEY `foreign_key_data_status_hub` (`id_status_hub`),
  ADD KEY `foreign_key_data_status_perkawinan` (`id_status_perkawinan`),
  ADD KEY `foreign_key_data_agama` (`id_agama`),
  ADD KEY `foreign_key_data_pekerjaan` (`id_pekerjaan`),
  ADD KEY `foreign_key_data_pendidikan` (`id_pendidikan`),
  ADD KEY `foreign_key_data_gl_darah` (`id_gol_darah`);

--
-- Indexes for table `jenis_kelamin`
--
ALTER TABLE `jenis_kelamin`
  ADD PRIMARY KEY (`id_jenis_kelamin`);

--
-- Indexes for table `pekerjaan`
--
ALTER TABLE `pekerjaan`
  ADD PRIMARY KEY (`id_pekerjaan`);

--
-- Indexes for table `pendidikan`
--
ALTER TABLE `pendidikan`
  ADD PRIMARY KEY (`id_pendidikan`);

--
-- Indexes for table `permohonan_ktp_wni`
--
ALTER TABLE `permohonan_ktp_wni`
  ADD PRIMARY KEY (`id_permohonan_ktp_wni`),
  ADD KEY `foreign_key_data_induk` (`id_induk`),
  ADD KEY `foreign_key_data_aparatur_desa` (`id_aparatur_desa`);

--
-- Indexes for table `status_hub`
--
ALTER TABLE `status_hub`
  ADD PRIMARY KEY (`id_status_hub`);

--
-- Indexes for table `status_perkawinan`
--
ALTER TABLE `status_perkawinan`
  ADD PRIMARY KEY (`id_status_perkawinan`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`IdUser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agama`
--
ALTER TABLE `agama`
  MODIFY `id_agama` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `aparatur_desa`
--
ALTER TABLE `aparatur_desa`
  MODIFY `id_aparatur_desa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `gol_darah`
--
ALTER TABLE `gol_darah`
  MODIFY `id_gol_darah` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `induk`
--
ALTER TABLE `induk`
  MODIFY `id_induk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `jenis_kelamin`
--
ALTER TABLE `jenis_kelamin`
  MODIFY `id_jenis_kelamin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `pekerjaan`
--
ALTER TABLE `pekerjaan`
  MODIFY `id_pekerjaan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `pendidikan`
--
ALTER TABLE `pendidikan`
  MODIFY `id_pendidikan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `permohonan_ktp_wni`
--
ALTER TABLE `permohonan_ktp_wni`
  MODIFY `id_permohonan_ktp_wni` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `status_hub`
--
ALTER TABLE `status_hub`
  MODIFY `id_status_hub` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `status_perkawinan`
--
ALTER TABLE `status_perkawinan`
  MODIFY `id_status_perkawinan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `IdUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `induk`
--
ALTER TABLE `induk`
  ADD CONSTRAINT `foreign_key_data_agama` FOREIGN KEY (`id_agama`) REFERENCES `agama` (`id_agama`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `foreign_key_data_gl_darah` FOREIGN KEY (`id_gol_darah`) REFERENCES `gol_darah` (`id_gol_darah`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `foreign_key_data_jenis_kelamin` FOREIGN KEY (`id_jenis_kelamin`) REFERENCES `jenis_kelamin` (`id_jenis_kelamin`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `foreign_key_data_pekerjaan` FOREIGN KEY (`id_pekerjaan`) REFERENCES `pekerjaan` (`id_pekerjaan`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `foreign_key_data_pendidikan` FOREIGN KEY (`id_pendidikan`) REFERENCES `pendidikan` (`id_pendidikan`),
  ADD CONSTRAINT `foreign_key_data_status_hub` FOREIGN KEY (`id_status_hub`) REFERENCES `status_hub` (`id_status_hub`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `foreign_key_data_status_perkawinan` FOREIGN KEY (`id_status_perkawinan`) REFERENCES `status_perkawinan` (`id_status_perkawinan`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `permohonan_ktp_wni`
--
ALTER TABLE `permohonan_ktp_wni`
  ADD CONSTRAINT `foreign_key_data_aparatur_desa` FOREIGN KEY (`id_aparatur_desa`) REFERENCES `aparatur_desa` (`id_aparatur_desa`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `foreign_key_data_induk` FOREIGN KEY (`id_induk`) REFERENCES `induk` (`id_induk`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
